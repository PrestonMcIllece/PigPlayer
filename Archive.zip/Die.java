/**
 *Preston McIllece's Project
 */
public class Die {
  
  protected int sides = 6;
  
  public static int roll()
  {
    double random;
    double roll;
    int returnedRoll = 0;

    random = Math.random();
    roll = random*6;
   
    if (roll >= 5)
    {
      returnedRoll = 6;
    }
    
    else if (roll < 5 && roll >= 4)
    {
      returnedRoll = 5;
    }
    
    else if (roll < 4 && roll >= 3)
    {
      returnedRoll = 4;
    }
    
    else if (roll < 3 && roll >= 2)
    {
      returnedRoll = 3;
    }
    
    else if (roll < 2 && roll >= 1)
    {
      returnedRoll = 2;
    }
    
    else if (roll < 1 && roll >= 0)
    {
      returnedRoll = 1;
    }
   return returnedRoll;
    }
  
  
  public void setSides(int numberOfSides)
  {
  }
  
  public int getSides()
         {
    return -1;
         }
         
  public int rollDie()
         {
    return -1;
         }


  public static void main(String[] args) { 
    
    Die d1 = new Die();
   
    for (int i = 0; i < 600; i++)
    {

    System.out.println(d1.roll());
    }

  }
  
}
