/**
 * Preston McIllece's Project
 */
public class PigGame {
  
protected static final int goal = 100;

  
}
