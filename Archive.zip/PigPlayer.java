/**
 * Auto Generated Java Class.
 */
public class PigPlayer extends PigGame {

  protected String playersName;
  protected int currentScore = 0;
  protected int gamesWon = 0;
  
  public PigPlayer(String name)
  {
    playersName = name;
  }
  
  public void setName(String name)
  {
    playersName = name;
  }
  
  public String getName()
  {
    return playersName;
  }
  
  public void reset()
  {
    currentScore = 0;
  }
  
  public void addPoints(int turnTotal)
  {
    currentScore += turnTotal;
    
    if (currentScore >= goal)
    {
      gamesWon++;
    }
  }
  
  public boolean won()
  {
    if (currentScore >= goal)
    {
      return true;
    }
    
    else
    {
      return false;
    }
  }
  
  public int getScore()
  {
    return currentScore;
  }
  
  public int getWinRecord()
  {
    return gamesWon;
  }
  
  public String toString()
  {
    return "Player's name: " + playersName + ". Player's current score: " + currentScore;
  }
  
  
  
   public static void main(String[] args) { 
     
     PigPlayer preston = new PigPlayer("Preston");
     System.out.println("Player name is " + preston.getName());
     
    preston.setName("Not Preston lol");
     System.out.println("Player name is " + preston.getName());
     
  
     preston.addPoints(22);
     preston.addPoints(12);
     preston.addPoints(66);
     System.out.println("Current score is " + preston.getScore());
     System.out.println(preston.won());
     
     preston.reset();
     System.out.println("Current score after reset is " + preston.getScore());
     System.out.println(preston.won());
     
     System.out.println("Player has won " + preston.getWinRecord() + " games.");
     
     
     
     
     
   }
}
